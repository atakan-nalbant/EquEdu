import { RouteObject, createBrowserRouter } from "react-router-dom";
import App from "./layout/App";
import HomePage from "./layout/page/HomePage";
import LoginPage from "./layout/page/LoginPage";
import CSProjectsPage from "./layout/page/ContentStudio/CSProjectsPage";
import CSEditor from "./layout/page/ContentStudio/CSEditor";
import Page404 from "./layout/page/Page404";
import constants from "./model/contants";


export const routes: RouteObject[] = [
    {
        path: '/',
        element: <App />,
        children: [
            { path: '', element: <HomePage /> },
            { path: constants.path.login, element: <LoginPage /> },
            { path: constants.path.contentStudioProjects, element: <CSProjectsPage /> },
            { path: '*', element: <Page404 /> },
            { path: constants.path.contentStudioProjects + "/:id", element: <CSEditor /> }
        ]
    }
];

export const router = createBrowserRouter(routes);