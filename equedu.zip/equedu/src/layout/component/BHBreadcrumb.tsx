// import { Breadcrumb } from 'semantic-ui-react'



// export default function BHBreadcrumb(props : {paths : String[]}) {
//     let paths = 
//     return (
//         <Breadcrumb>
//         {

//         }
//             <Breadcrumb.Section link>Home</Breadcrumb.Section>
//             <Breadcrumb.Divider icon='right chevron' />
//             <Breadcrumb.Section link>Registration</Breadcrumb.Section>
//             <Breadcrumb.Divider icon='right arrow' />
//             <Breadcrumb.Section active>Personal Information</Breadcrumb.Section>
//         </Breadcrumb>
//     )
// }

