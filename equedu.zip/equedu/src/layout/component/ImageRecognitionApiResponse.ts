export type ImageRecognitionApiResponse = {
    objectsResult?: {
        values: {
            boundingBox: BoundingBox;
            tags: Tag[];
        }[]
    },
    denseCaptionsResult?: {
        values: {
            text: string;
            confidence: number;
            boundingBox: BoundingBox;
        }[]
    },
    modelVersion?: string;
    metadata?: {
        width: number;
        height: number;
    },
    peopleResult?: {
        values: {
            boundingBox: BoundingBox;
            confidence: number
        }[]
    }
}

type BoundingBox = {
    x: number;
    y: number;
    w: number;
    h: number;
}

type Tag = {
    name: string;
    confidence: number;
}