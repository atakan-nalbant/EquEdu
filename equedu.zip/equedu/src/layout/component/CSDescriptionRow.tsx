import { MouseEventHandler, /*memo*/ } from "react";
import { Button, Divider, /*Grid, Icon, Loader, Segment*/ } from "semantic-ui-react";

import { DubType, Description } from "../../model/ProjectTypes";
// import constants from "../../model/contants";

type DescriptionRowProps = {
    description: Description
    editAction: MouseEventHandler
    deleteAction: MouseEventHandler
}

export default function CSDescriptionRow(props: DescriptionRowProps) {
    let description = props.description

    const startTimeHMS = new Date(description.startTime * 1000).toISOString().slice(11, 19);

    return (
        <div id={"duration-" + description.startTime}>
            <div style={{ padding: 6, paddingBottom: 12 }}>
                <div style={{paddingBottom: 6}}>
                    <label><b>{startTimeHMS}</b></label>
                    <label style={{ margin: 6 }} >:</label>
                    <label>{description.description}</label>

                </div>

                <label>Description Type:<br /><i>{DubType[description.dubType]}</i></label>

                <div style={{width: "100%", textAlign: "right", marginTop: 12}}>
                <Button.Group>
                    <Button
                        onClick={props.editAction}>
                        Edit
                    </Button>

                    <Button.Or text='or' />

                    <Button
                        negative
                        onClick={props.deleteAction}>
                        Delete
                    </Button>
                </Button.Group>
                </div>

            </div>

            <Divider></Divider>

        </div>
    );

}
