import { useRef } from "react";
import { Button, Icon } from "semantic-ui-react";

export default function VideoUploadButton() {
  const fileInputRef = useRef<HTMLInputElement>(null);

  const openFileInput = () => {
    if (fileInputRef.current) {
      fileInputRef.current.click();
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.item(0);
    console.log(file);
    e.target.value = "";
  };

  
  return (
    <div>
      <Button onClick={openFileInput} primary icon>
        <Icon name="upload" /> Upload Video
      </Button>
      <input ref={fileInputRef} type="file" hidden accept="video/*" onChange={handleFileChange}/>
    </div>
  );
}
