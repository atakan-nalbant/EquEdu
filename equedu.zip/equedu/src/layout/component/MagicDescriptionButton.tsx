import { useState } from "react";
import { Button, Icon, Loader } from "semantic-ui-react";
import { ImageRecognitionApiResponse } from "./ImageRecognitionApiResponse";


function denseCaptionApi(blob: Blob): Promise<ImageRecognitionApiResponse> {
    let url = "https://<>-hackathon.cognitiveservices.azure.com/computervision/imageanalysis:analyze?api-version=2023-04-01-preview&features=denseCaptions,objects,people"
    let key = "<key>"
    let headers = {
        "Ocp-Apim-Subscription-Key": key,
        "Content-Type": "application/octet-stream"
    }

    return new Promise((res, _rej) => {
        fetch(url, { headers: headers, body: blob, method: "POST" }).then(response => {
            // console.log(response.json())
            res(response.json() as ImageRecognitionApiResponse)
        })
    })
}

function responseMapper(response: ImageRecognitionApiResponse): string {
    let text = ""

    // Dense Captions
    if ("denseCaptionsResult" in response) {
        let sorted = response.denseCaptionsResult!.values.sort((i, j) => {
            return (i.confidence < j.confidence ? +1 : (i.confidence > j.confidence ? -1 : 0))
        })
        let top3 = sorted.slice(0, 3)
        let topCaptions = top3.map(dCaption => dCaption.text).join("\nOR : ")
        text += "Top Descriptions: \n" + topCaptions
    }

    // People Count
    if ("peopleResult" in response) {
        let pResults = response.peopleResult!.values.filter(pRes => pRes.confidence > 0.5)
        let peopleCount = pResults.length
        text += peopleCount > 0 ? "\nThere are probably " + peopleCount + " visible." : ""
    }

    //TAGS
    if ("objectsResult" in response) {
        let tags = response.objectsResult!.values.map(val => {
            val.tags.map(tag => { tag.name })
        }).join(", ")

        text += tags !== "" ? ("\nTAGS: " + tags) : ""
    }

    return text
}

export default function MagicDescriptionButton() {

    const [magicState, setMagicState] = useState<"init" | "processing">("init")


    function generateMagicDescription() {
        setMagicState("processing")
        getFrame().then((blob) => {
            denseCaptionApi(blob).then(apiResponse => {
                console.log(apiResponse)
                let text = responseMapper(apiResponse)
                console.log(text)
                let textArea = document.getElementsByTagName("textarea")[0]
                textArea.value = text
                console.log(apiResponse)
                setMagicState("init")
            })
        })
    }

    function getFrame(): Promise<Blob> {
        return new Promise((res, rej) => {
            let video = document.getElementsByTagName("video")[0]
            var canvas = document.createElement("canvas");
            canvas.width = video.videoWidth;
            canvas.height = video.videoWidth;
            var canvasContext = canvas.getContext("2d") as CanvasRenderingContext2D;
            canvasContext.drawImage(video, 0, 0);
            canvas.toBlob(data => { data !== undefined ? res(data as Blob) : rej() })
        })
    }


    return (

        <div style={{ margin: 24, display: "flex", alignContent: "center", justifyContent: "center" }}>

            <label style={{ padding: 0, margin: 0, marginRight: 24, width: 250 }}>Don't sure how to describe this moment? Use AI Generated Descriptions</label>

            <Button primary size="big" style={{ marginLeft: 12 }} onClick={() => generateMagicDescription()}>

                {magicState === "init" ? <Icon name="magic"></Icon> : <Icon name="check circle outline"></Icon>}

                <Loader size="mini" active={magicState === "processing"} inline inverted></Loader>

                <label style={{ padding: 12 }}>
                    {magicState === "init" ? "Generate AI-assisted Description" : "Processing"}
                </label>

            </Button>
        </div>
    )

}