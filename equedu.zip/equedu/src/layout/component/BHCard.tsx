import { Card, Icon, SemanticICONS } from 'semantic-ui-react'
import { Link } from "react-router-dom";

type CardProps = {
    title: String;
    language: String;
    href: String;
    icon?: SemanticICONS;
}

export default function BHCard(props: CardProps) {
    let title = props.title;
    let language = props.language
    let href = props.href
    let icon = props.icon === undefined ? "video" : props.icon


    return (
        <center>
            <Card as={Link} to={href}>
                <center>
                        <Icon style={{ margin: 24 }} size="huge" name={icon} className='blueToGreen'></Icon>
                </center>
                {/* <Image src='https://react.semantic-ui.com/images/avatar/large/matthew.png' wrapped ui={false} /> */}
                <Card.Content>
                    <Card.Header>{title}</Card.Header>
                    {/* <Card.Meta>
                <span className='date'>Joined in 2015</span>
            </Card.Meta> */}
                    {/* <Card.Description>
                Matthew is a musician living in Nashville.
            </Card.Description> */}
                </Card.Content>
                {language !== "" &&
                    <Card.Content extra>
                        <a><Icon name="language" /> Language: {language.toUpperCase()}</a>
                    </Card.Content>
                }

            </Card>
        </center>
    )
}

