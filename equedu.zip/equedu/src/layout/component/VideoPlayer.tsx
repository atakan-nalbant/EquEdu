import React, { forwardRef, memo, useRef } from 'react';
import { Button, Icon, SemanticICONS } from 'semantic-ui-react';
import Plyr from 'plyr-react';

interface VideoPlayerProps {
  videoUrl: string;
  plyrProps: any;
  title: string;
  icon: SemanticICONS;
  handleFileChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
}

// First, wrap the component with forwardRef
const VideoPlayerAndUpload = forwardRef<HTMLInputElement, VideoPlayerProps>(
  ({ videoUrl, plyrProps, title, icon, handleFileChange }, ref) => {
    const fileInputRef = useRef<HTMLInputElement>(null);

    const openFileInput = () => {
      fileInputRef.current?.click();
    };

    return (
      <div style={{ textAlign: "center", minHeight: 300, maxHeight: "calc(100vh - 400px)" }}>
        {videoUrl ? (
          <Plyr ref={ref} {...plyrProps} style={{ maxHeight: "calc(100vh - 448px)" }} autoPlay/>
        ) : (
          <Button onClick={openFileInput} primary style={{ marginTop: 130 }}>
            <Icon name={icon} />
            {title}
          </Button>
        )}

        <input ref={fileInputRef} type="file" hidden accept="video/*" onChange={handleFileChange} />

      </div>
    );
  }
);

// Then, wrap the result with memo
const MemoizedVideoPlayer = memo(VideoPlayerAndUpload, (prevProps, nextProps) => {
  return prevProps.videoUrl === nextProps.videoUrl && prevProps.plyrProps === nextProps.plyrProps;
});

export default MemoizedVideoPlayer;