import { Link, useNavigate } from "react-router-dom";
import { Button, Container, Image, /*Label,*/ Menu } from "semantic-ui-react";
import logo from "../logo.png"
import { Fragment, useContext, useEffect, /*useState*/ } from "react";
import { useAuthState } from "react-hooks/auth";
import auth, { signout } from "../../model/azureLoginModel";
import constants from "../../model/contants";
import { UserContext } from "../App";

export default function NavBar() {
    const [user, _uLoading, _uError] = useAuthState(auth);
    const { userInfoInContext } = useContext(UserContext);

    const navigate = useNavigate();
    let userID = "";
    useEffect(() => {
        if (user) {
            userID = user.uid;
            console.log("This user is logged in:", user, "User ID is:", userID);
        } else {
            console.log("This user is a guest user.");
        }
    }, []);

    const handleLogout = () => {
        signout().then(() => {
            console.log("User signed out.");
            navigate("/");
        }).catch(error => {
            console.log("Error signing out:", error);
        })
    };

    return (
        <>
            <Menu inverted fixed="top">
                <Container>
                    <Menu.Item name="EquEdu">
                    </Menu.Item>
                    {user && (
                        <Fragment>
                            <Menu.Item name="Content Studio" as={Link} to={constants.path.contentStudioProjects} />
                            <Menu.Item content={<p>Training<br></br><i>(coming soon)</i></p>} />
                        </Fragment>
                    )}
                    <Menu.Item position="right">

                        {user && userInfoInContext &&
                            <Fragment>
                                <Menu.Item name={"Remaining Minutes:" + userInfoInContext?.remainingMinutes.toString()} />
                            </Fragment>
                        }

                        {user ? (
                            <Button basic inverted content="Log Out" onClick={handleLogout} />
                        ) : (
                            <Button as={Link} to="/login" basic inverted content="Login" />
                        )}
                    </Menu.Item>
                </Container>
            </Menu>
            {/* <Label></Label> */}
        </>
    );
}
