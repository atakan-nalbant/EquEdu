import { Header, /*Icon, Button, GridColumn,*/ Grid, Divider } from "semantic-ui-react";
import BHCard from "../../component/BHCard"
import { UserContext } from "../../App";
import { useContext, useEffect } from "react";
import auth from "../../../model/azureLoginModel";
import { useAuthState } from "react-hooks/auth";
import { getUserDetail_db } from "../../../model/NetworkModel";


export default function CSProjectsPage() {
    const { userInfoInContext, setUserInfoToContext } = useContext(UserContext);
    const [user, _uLoading, _uError] = useAuthState(auth);


    // Checks every page renews / loads
    useEffect(() => {
        // console.log("USER called effect")
        // console.log("user",user, "userInfoInContext", userInfoInContext)

        if (user && userInfoInContext === undefined) {
            console.log("user", user, "userInfoInContext", userInfoInContext)
            console.log("inside the function set")
            getUserDetail_db(user.uid).then(userInfo => {
                console.log("setting userInfo to the context")
                setUserInfoToContext(userInfo)
            })
        }
    }, [])

    return (
        <>
            {/* <div> */}
            <Header as='h1' icon>Content Studio</Header>
            {/* </div> */}

            <BHCard title={"Create New Project"} language={""} href={"new"} icon="add"></BHCard>

            <Divider section />

            {
                userInfoInContext &&
                userInfoInContext.projects.length > 0 &&

                <>
                    <Header as='h1' icon>Existing Projects</Header>
                    <Grid columns={3}>
                        {
                            userInfoInContext.projects.map((p, _i) => {
                                return <Grid.Column>
                                    <BHCard title={p.projectName} href={p.projectId} language={p.language ? p.language : ""}></BHCard>
                                </Grid.Column>
                            })

                        }
                    </Grid>
                </>

            }

            {
                userInfoInContext === undefined || userInfoInContext.projects.length === 0 &&
                <p>There is no created project.</p>
            }




        </>
    );
}

