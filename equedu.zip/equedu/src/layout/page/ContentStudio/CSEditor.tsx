// import { Field } from "formik";
import "plyr-react/plyr.css";
import React, { /*MouseEventHandler, useCallback,*/ useContext, useEffect, useMemo, useRef, useState } from "react";
import { Button, Divider, Grid, Header, Loader, Segment, TextArea, Form, Icon, Modal, Input, Select, Popup } from "semantic-ui-react";
import CSDescriptionRow from "../../component/CSDescriptionRow";
import VideoPlayer from "../../component/VideoPlayer";
import { Link, useNavigate, useParams } from "react-router-dom";
import constants from "../../../model/contants";
import { Description, DubType, DubTypeKeys, ProjectInfo } from "../../../model/ProjectTypes";
import { createProject_db, getProjectDetail_db, processProject_db, putProjectDetail_db, uploadMedia_db } from "../../../model/NetworkModel";
import { useAuthState } from "react-hooks/auth";
import auth from "../../../model/azureLoginModel";
import { UserContext } from "../../App";
import { UserInfo } from "../../../model/UserTypes";
import MagicDescriptionButton from "../../component/MagicDescriptionButton";


export default function CSEditor() {
    // Fundamental States
    const { userInfoInContext, setUserInfoToContext } = useContext(UserContext);
    const [user, _uLoading, _uError] = useAuthState(auth);
    const navigate = useNavigate();

    let { id } = useParams()
    let projectId = id

    const [projectInfo, setProjectInfo] = useState<ProjectInfo>({
        projectId: projectId as string,
        projectName: "Loading Project Information",
        language: "tr",
        authorizedUIDs: ["0"],
        descriptions: []
    })
    const [isProjectLoaded, setIsProjectLoaded] = useState(false);

    const [allDescriptions, setAllDescriptions] = useState<Description[]>([])

    // Video States
    // State to hold the video URL. When a video is uploaded, videoURL will be updated to the object URL of the video
    const [videoUrl, setVideoUrl] = useState("");
    const [isVideoLoading, setIsVideoLoading] = useState(false);

    // Description Entry States
    const [descriptionInTheBox, setDescriptionFromTheBox] = useState("")
    const [estimatedDuration, setEstimatedDuration] = useState(0)

    // Toggles
    const [openModal, setOpenModal] = useState(false)
    const [descriptionAdditionMode, setDescriptionAdditionMode] = useState<"Add" | "Update">("Add")

    const videoRef = useRef<any>(null);
    const dubTypeRef = useRef<any>(null);
    const textareaRef = useRef<any>(null);

    // Plyr Configurations
    const plyrProps = useMemo(() => ({
        source: {
            type: "video",
            title: "Uploaded Video",
            sources: videoUrl ? [{
                src: videoUrl, // Use the state for the video source
                type: "video/mp4",
            }] : [],
        },
        options: {
            enabled: true,
            controls: ["play-large", "play", "progress", "current-time", "mute", "volume", "captions", "settings", "fullscreen"],
        },
    }), [videoUrl]);

    // Cleanup effect
    useEffect(() => {
        return () => {
            if (videoUrl) {
                URL.revokeObjectURL(videoUrl);
            }
        };
    }, [videoUrl]);


    //LOADS PROJECT
    // To call only one time, passing empty array will stop recalls with renders. Because there is no dependency.
    useEffect(() => {
        if (projectId === "new") {
            let p = projectInfo
            p.projectName = "Define Your Project Name by Clicking this Icon"
            p.authorizedUIDs = [userInfoInContext?.userId as string]
            setProjectInfo(p)
            setIsProjectLoaded(true)
        } else {
            getProjectDetail_db(userInfoInContext?.userId as string, projectId as String).then(pInfo => {
                setProjectInfo(pInfo)
                setAllDescriptions(pInfo.descriptions)
                setVideoUploadState(pInfo.processStatus?.inputFileExists ? "Uploaded" : "NotSelected")
                setIsProjectLoaded(true)
            })
        }
    }, [])


    function setAllDescriptionsAndProj(descriptions: Description[]) {
        setAllDescriptions(descriptions)
        let p = projectInfo
        p.descriptions = descriptions
        setProjectInfo(p)
    }

    function loadVideo(file: File) {
        let shouldUploadFile = !(projectInfo.processStatus?.inputFileExists)
        if (shouldUploadFile) {

            setVideoUploadState("Uploading")

            uploadMedia_db(user?.uid as string, projectId as string, file).then(loaded => {
                if (loaded) { setVideoUploadState("Uploaded") }
                else { setVideoUploadState("Error") }
            }).catch(_e => {
                setVideoUploadState("Error")
            })
        } else {
            setVideoUploadState("Uploaded")
        }
    }

    const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files?.[0];
        if (file) {
            setIsVideoLoading(true);
            const videoObjectUrl = URL.createObjectURL(file);
            setVideoUrl(videoObjectUrl); // Set the video URL to the object URL
            loadVideo(file);
            // Cleanup the old video object URL
            // setTimeout(() => {
            setIsVideoLoading(false);
            // }, 500); // Adjust the time based on expected load time
            return () => {
                URL.revokeObjectURL(videoObjectUrl);
            };
        }
    };

    function sortDescriptions(descriptionsArray: Description[]) {
        return descriptionsArray.sort((d1, d2) => {
            return d1.startTime - d2.startTime
        })
    }

    function addDescription(d: Description) {
        setAllDescriptionsAndProj(sortDescriptions([...allDescriptions, d]))
    }

    function deleteDescription(d: Description) {
        let filtered = allDescriptions.filter(desc => desc !== d)
        setAllDescriptionsAndProj(filtered); // No need to filter again.
    }

    function updateDescription(description: Description) {
        let startTime = description.startTime
        var newDescs = new Array(allDescriptions.length)

        for (let i = 0; i < allDescriptions.length; i++) {
            const d = allDescriptions[i];
            if (d.startTime === startTime) {
                newDescs[i] = description // object we'll update
            } else {
                newDescs[i] = d // onjects other than our desired object
            }
        }

        setAllDescriptionsAndProj(sortDescriptions(newDescs));
    }

    let addDescriptionHandler = (_e: React.MouseEvent<HTMLElement>) => {
        let startTime = Math.floor(videoRef.current.plyr.currentTime)
        console.log(descriptionInTheBox)

        let descriptionInContext: Description = {
            description: descriptionInTheBox,
            startTime: startTime,
            dubType: dubTypeRef.current!.value
        }

        console.log(descriptionInContext)

        if (descriptionAdditionMode === "Add") { // Create situation
            addDescription(descriptionInContext)
        } else {
            updateDescription(descriptionInContext) // Update situation
            setDescriptionAdditionMode("Update")
        }

        // setDescriptionFromTheBox("")
        // Empty Text in the box.
        textareaRef.current.value = ""
        videoRef.current.plyr.play()
    }

    function editDescriptionHandler(d: Description) {
        // Video Seek
        videoRef.current.plyr.pause()
        videoRef.current.plyr.currentTime = d.startTime
        // Setting text of the edit area
        textareaRef.current.value = d.description

        setDescriptionAdditionMode("Add")
        // setTIB(d.description)
        console.log(d)
        // textareaRef.current.value = d.descriptionText
        // setDescriptionAdditionMode("update")
    }

    function modal() {
        const pNameRef = useRef<any>(null);

        return <Modal onClose={() => setOpenModal(false)} onOpen={() => setOpenModal(true)} open={openModal} >
            <Modal.Header>Edit Project Info</Modal.Header>
            <Modal.Content>
                <Input style={{ width: "100%" }} ref={pNameRef} placeholder='Project Name' label="Project Name" defaultValue={projectInfo.projectName}></Input>
                <br /><br />
                <div style={{ display: "flex", alignItems: "center" }}>
                    <label style={{ padding: 0 }}>Project Language: </label>
                    <Select style={{ flexGrow: 1 }} options={[{ text: "English", value: "en" }, { text: "Türkçe", value: "tr" }]}
                        defaultValue={projectInfo.language ? projectInfo.language : "en"}
                        onChange={(_event, data) => {
                            let selectedLang = data.value as ("en" | "tr")
                            let p = projectInfo
                            p.language = selectedLang
                            setProjectInfo(p)
                        }}
                    />
                </div>
            </Modal.Content>
            <Modal.Actions>
                <Button onClick={() => setOpenModal(false)}>Close</Button>
                <Button
                    content="Update Project Info"
                    onClick={() => {
                        let p = projectInfo
                        p.projectName = pNameRef.current!.value
                        setProjectInfo(p)
                        setOpenModal(false)
                    }}
                    positive
                />
            </Modal.Actions>
        </Modal>
    }



    const [saveProgressButtonText, setSaveProgressButtonText] = useState("Saving Project...")
    function saveProjectButtonAction() {
        console.log("saveProjectButtonAction", projectInfo.projectId)
        if (projectInfo.projectId !== "new") {
            // Returns ProjectInfo, no need to set it again
            putProjectDetail_db(user?.uid as string, projectInfo).then(pInfo => {
                setProjectInfo(pInfo)
                setSaveProgressButtonText("Project Saved ✅")
            })
        } else {
            console.log("begin request")
            createProject_db(user?.uid as string, projectInfo).then(pInfo => {
                // Set project, with new ID.
                console.log("received pInfo", pInfo)

                setProjectInfo(pInfo)
                console.log("set Project info")

                //Set user context
                let uInfo = userInfoInContext as UserInfo
                uInfo?.projects.push(pInfo)
                setUserInfoToContext(uInfo)
                console.log("set context")

                setSaveProgressButtonText("Project Created + Saved ✅")
                // Navigate to the new project url with ID.
                navigate("/" + constants.path.contentStudioProjects + "/" + pInfo.projectId, { replace: true })
            })
        }

    }

    const [startProcessButtonText, setStartProcessButtonText] = useState("Starting to preparing project...")
    function startProcessing() {
        // Returns ProjectInfo, no need to set it again
        processProject_db(user?.uid as string, projectInfo).then(status => {
            setStartProcessButtonText(status ? "Preparation started, you should be able to download project within 5 minutes." : "Error happened.")
        })
    }

    const [videoUploadState, setVideoUploadState] = useState<"NotSelected" | "Uploading" | "Uploaded" | "Error">("NotSelected")
    const [projectEditMode, setProjectEditMode] = useState<Boolean>(false)

    return (

        <div style={{ textAlign: "left", paddingLeft: 48, paddingRight: 48 }}>

            {modal()}

            <Grid>

                <Grid.Row verticalAlign="middle" stretched>

                    <Header>
                        <a onClick={(_e) => setOpenModal(true)}><Icon name="edit outline"></Icon></a>
                        {projectInfo.projectName}
                    </Header>

                    <div style={{ flexGrow: 1 }}></div>


                    {/* UPLOAD STATUS */}
                    {
                        videoUploadState === "Uploading" &&
                        <>
                            <Loader active inline></Loader>
                            <label style={{ margin: 0, paddingLeft: 12 }}>
                                Uploading Video<br />
                                <i>Don't close the window, while uploading.</i>
                            </label>
                        </>
                    }
                    {
                        videoUploadState === "Uploaded" &&
                        <>
                            <Icon size="big" name="checkmark"></Icon>
                            <label style={{ margin: 0, paddingLeft: 12 }}>
                                Video Uploaded for the Project<br />
                                <i>You may close the window, after saving the<br />project or clicking to the "Prepare Movie".</i>
                            </label>
                        </>
                    }
                    {
                        videoUploadState === "Error" &&
                        <>
                            <Icon size="big" name="warning sign"></Icon>
                            <label style={{ margin: 0, paddingLeft: 12 }}>
                                Error<br />
                                <i>An error happened,<br />while uploading.</i>
                            </label>
                        </>
                    }


                    <div style={{ flexGrow: 1 }}></div>


                    <Popup
                        content={saveProgressButtonText}
                        on="click"
                        pinned
                        trigger={
                            <Button primary
                                onClick={(_e) => { saveProjectButtonAction() }}
                            // disabled={allDescriptions.length === 0}
                            >
                                <Icon name="save"></Icon>
                                Save Project
                            </Button>
                        }
                    />

                    <Popup
                        content={startProcessButtonText}
                        on="click"
                        pinned
                        trigger={
                            <Button color="black"
                                onClick={_e => startProcessing()}
                                disabled={allDescriptions.length === 0}
                            >
                                <Icon name="film"></Icon>
                                Prepare Movie
                            </Button>
                        }
                    />



                </Grid.Row>

                <Grid.Row>
                    <Grid.Column width={12}>
                        <Segment textAlign="center">

                            {
                                !isProjectLoaded ? (
                                    <Loader active inline="centered" style={{ margin: 150 }}>
                                        Loading Project...
                                    </Loader>
                                )
                                    :
                                    (
                                        isVideoLoading ? (
                                            <Loader active inline="centered" style={{ margin: 150 }}>
                                                Loading Video...
                                            </Loader>
                                        ) : (
                                            isProjectLoaded && (!(projectInfo.processStatus?.processedFileExists) || projectEditMode) ?
                                                <VideoPlayer
                                                    videoUrl={videoUrl}
                                                    plyrProps={plyrProps}
                                                    handleFileChange={handleFileChange}
                                                    ref={videoRef}
                                                    title={videoUploadState !== "Uploaded" ? "Upload Video to Start" : "Reselect your Video for this Project from your Computer"}
                                                    icon={videoUploadState !== "Uploaded" ? "upload" : "folder open"} />
                                                :
                                                <div style={{ margin: 150 }}>
                                                    <p>Your project is prepared and it's ready to download.</p>
                                                    <Button as={Link} to={constants.path.apiBaseUrl + projectInfo.processStatus?.downloadLink as string} primary >
                                                        <Icon name="cloud download"></Icon>
                                                        Download Prepared File
                                                    </Button>
                                                    <p style={{ marginTop: 24 }}>Do you want to re-edit your project?</p>
                                                    <Button onClick={(_e) => setProjectEditMode(true)}>
                                                        <Icon name="edit outline"></Icon>
                                                        Edit Project
                                                    </Button>
                                                </div>
                                        )
                                    )
                            }


                            {videoUrl !== "" && !isVideoLoading &&
                                <>
                                    <Divider></Divider>

                                    <MagicDescriptionButton></MagicDescriptionButton>

                                    <Grid>
                                        <Grid.Column width={14}>
                                            <Form>
                                                <TextArea ref={textareaRef}
                                                    style={{ minHeight: 100, marginBottom: 24 }}
                                                    placeholder='Add a description for this moment.'
                                                    onFocus={(_e: React.MouseEvent<HTMLElement>) => {
                                                        videoRef.current.plyr.pause()
                                                    }}
                                                    onChange={
                                                        (e) => {
                                                            let text = e.target.value
                                                            setDescriptionFromTheBox(text);
                                                            let wordCount = text.split(" ").length
                                                            let duration = text.length === 0 ? 0 : Math.ceil((wordCount / constants.wordsPerMinute * 60)) // as seconds
                                                            setEstimatedDuration(duration)
                                                        }
                                                    }
                                                />
                                            </Form>

                                            <div>
                                                <label style={{ marginRight: 24 }}>Dub Type:</label>
                                                <select ref={dubTypeRef} name="dubType" id="dubTypeSelect" style={{ maxWidth: "calc(100% - 100px)" }}>
                                                    {
                                                        Object.keys(DubType).map(type => (
                                                            <option value={type}>{DubType[type as DubTypeKeys]}</option>
                                                        ))
                                                    }
                                                </select>
                                            </div>
                                            <div>
                                                <label style={{ marginRight: 12 }}>{constants.localization.estimatedDuration} : </label>
                                                <label><i>{estimatedDuration} {constants.localization.seconds}</i></label>
                                            </div>

                                        </Grid.Column>

                                        <Grid.Column width={2}>
                                            <Button primary
                                                onClick={addDescriptionHandler}
                                                disabled={descriptionInTheBox.length === 0}
                                                style={{ width: "100%", height: "100%" }}>
                                                <Icon name="add"></Icon>
                                                Add Description
                                            </Button>
                                        </Grid.Column>
                                    </Grid>
                                </>
                            }

                        </Segment>
                    </Grid.Column>
                    <Grid.Column width={4}>
                        <Segment style={{ maxHeight: "calc(100vh - 200px)", overflowY: "scroll" }}>


                            <h2>{constants.localization.audioDescriptionsTitle}</h2>
                            {
                                allDescriptions.length === 0
                                    ?
                                    <p>{constants.localization.enterDesriptionHint}</p>
                                    :
                                    videoUrl !== "" ?
                                        <>
                                            {
                                                !projectInfo.processStatus?.processedFileExists || projectEditMode ?
                                                    allDescriptions.map(d => (
                                                        <CSDescriptionRow
                                                            key={"description-at-" + d.startTime}
                                                            description={d}
                                                            editAction={(_e) => { editDescriptionHandler(d) }}
                                                            deleteAction={(_e) => { deleteDescription(d) }}
                                                        />
                                                    ))
                                                    :
                                                    <p>
                                                        This project has {allDescriptions.length} audio descriptions.
                                                        <br />
                                                        <br />
                                                        To view or edit the descriptions please click to the Edit/Reprepare Project button, from the left side.
                                                    </p>
                                            }
                                        </>
                                        :
                                        <p>
                                            This project has {allDescriptions.length} audio descriptions.
                                            <br />
                                            <br />
                                            To view or edit the descriptions please select the video from your computer.
                                        </p>
                            }

                        </Segment>
                    </Grid.Column>

                </Grid.Row>

            </Grid>


        </div >
    );
}