import { Formik, Form, Field, ErrorMessage } from "formik";
import * as Yup from "yup";
import { Button, Label } from "semantic-ui-react";
import { useContext, /*useEffect,*/ useState } from "react";
import { useNavigate } from "react-router-dom";
import /*auth,*/ { signin } from "../../model/azureLoginModel";
import { UserContext } from "../App";
import { getUserDetail_db } from "../../model/NetworkModel";

// Validation schema using Yup
const LoginSchema = Yup.object().shape({
    email: Yup.string()
        .email("Invalid email address")
        .required("Email is required"),
    password: Yup.string().required("Password is required"),
});

export default function LoginForm() {
    const navigate = useNavigate();
    const [generalError, setGeneralError] = useState(""); // State for general errors
    const {setUserInfoToContext} = useContext(UserContext);

    return (
        <div>
            <Formik
                initialValues={{ email: "", password: "" }}
                validationSchema={LoginSchema}
                onSubmit={async (values, { setSubmitting }) => {
                    signin(values.email, values.password).then(userCredential => {
                        console.log("User signed in:", userCredential.user);

                        //Fetching user info
                        getUserDetail_db(userCredential.user.uid).then(userInfo => {
                            console.log("setting userInfo to the context")
                            setUserInfoToContext(userInfo)
                            navigate("/"); // Navigate to home after successful login
                        })
                        
                    }).catch(error => {
                        setSubmitting(false);
                        console.log(error.message);
                        setGeneralError("Invalid email or password. Please try again.");
                    })
                }}
            >
                {({ isSubmitting }) => (
                    <Form className="ui form" autoComplete="off">
                        <div>
                            <Label htmlFor="email">Email:</Label>
                            <Field name="email" type="email" />
                            <ErrorMessage
                                name="email"
                                component="div"
                                className="ui error message"
                            />
                        </div>
                        <div>
                            <Label htmlFor="password">Password:</Label>
                            <Field name="password" type="password" />
                            <ErrorMessage
                                name="password"
                                component="div"
                                className="ui error message"
                            />
                        </div>

                        {/* Display the general error message */}
                        {generalError && (
                            <div className="ui error message" id="errorLabel">
                                <p>{generalError}</p>
                            </div>
                        )}

                        <Button
                            positive
                            type="submit"
                            loading={isSubmitting}
                            disabled={isSubmitting}
                        >
                            Sign In
                        </Button>
                    </Form>
                )}
            </Formik>
        </div>
    );
}
