import { Header, Icon, Button } from "semantic-ui-react";
import { Link } from "react-router-dom";


export default function Page404() {

    return (
        <>
            <div>
                <Header as='h1' icon>
                    <Icon name='warning sign' />
                    404 | Not Found
                </Header>
            </div>

            <div style={{ padding: 24 }}>
                <Button as={Link} to="/" primary>Go Back</Button>
            </div>

        </>
    );
}

