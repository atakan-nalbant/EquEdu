import { Header, Icon, Button } from "semantic-ui-react";
import { Link } from "react-router-dom";
import auth from "../../model/azureLoginModel";
import { useAuthState } from "react-hooks/auth";
import constants from "../../model/contants";

export default function HomePage() {
    const [user, _uLoading, _uError] = useAuthState(auth);

    return (
        <>
            <div>
                <Header as='h1' icon>
                    <Icon name='universal access' />
                    EquEdu Content Hub
                    <Header.Subheader>
                        Make your content accessible.
                    </Header.Subheader>
                </Header>
            </div>

            {
                user ?
                    <>
                        <div style={{ padding: 24 }}>
                            <Button as={Link} to={constants.path.contentStudioProjects} primary>Browse Content Studio Projects</Button>
                        </div>
                        <div style={{ padding: 24 }}>
                            <Button as={Link} to={constants.path.training} primary disabled>Training (coming soon)</Button>
                        </div>
                    </>
                    :
                    <>
                        <div style={{ padding: 24 }}>
                            <Button as={Link} to="/login" primary>Log in to Start</Button>
                        </div>

                        <div style={{ padding: 24 }}>
                            <p>Interested in a demo?</p>
                            <Button as={Link} to="mailto:atakan@nalbant.me">
                                Contact us to Create Account
                                <Icon name="mail" style={{ paddingLeft: 12 }} />
                            </Button>
                        </div>
                    </>

            }


        </>
    );
}

