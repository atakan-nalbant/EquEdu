import { Outlet } from "react-router-dom";
import NavBar from "./Partial/NavBar";
import { Container, Loader } from "semantic-ui-react";
import { createContext, /*useEffect,*/ useState } from "react";
import { UserInfo } from "../model/UserTypes";
import { useAuthState } from "react-hooks/auth";
import auth from "../model/azureLoginModel";
import { getUserDetail_db } from "../model/NetworkModel";


type UserContextType = {
    userInfoInContext: UserInfo | undefined;
    setUserInfoToContext: (c: UserInfo) => void;

}


export const UserContext = createContext<UserContextType>({
    userInfoInContext: undefined,
    setUserInfoToContext: () => { }
});


export default function App() {
    const [userInfoInContext, setUserInfoToContext] = useState<UserInfo | undefined>(undefined);
    const [user, uLoading, uError] = useAuthState(auth);

    if (!userInfoInContext) {
        if (user) {
            getUserDetail_db(user.uid).then(uInfo => setUserInfoToContext(uInfo))
        }
    }

    return (
        <>
            <UserContext.Provider value={{ userInfoInContext, setUserInfoToContext }}>
                <NavBar />
                <Container fluid textAlign="center" style={{ paddingTop: "7em" }}>
                    {
                        (!user && !uLoading || uError) &&
                        <p>Please sign in</p>
                    }

                    {
                        userInfoInContext === undefined &&
                        <Loader>Loading...</Loader>
                    }
                    <Outlet />
                </Container>
            </UserContext.Provider>
        </>
    );
}

