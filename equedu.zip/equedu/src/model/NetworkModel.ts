import { ProjectInfo } from "./ProjectTypes";
import { UserInfo } from "./UserTypes";
import constants from "./contants";

const baseURL = constants.path.apiBaseUrl


let authHeader = (uid: string) => {
    return {
        "Content-Type": "application/json",
        "user-id": uid
    }
}


export function getUserDetail_db(uid: string): Promise<UserInfo> {
    return new Promise((res, _rej) => {
        fetch(baseURL + "/me", {
            method: "GET",
            headers: authHeader(uid = uid),
            redirect: "follow"
        }).then(response => {
            let resp = response.json() as Object
            let uInfo = resp as UserInfo
            res(uInfo)
        })
    })
}


export function createProject_db(uid: string, project: ProjectInfo): Promise<ProjectInfo> {
    return new Promise((res, _rej) => {
        fetch(baseURL + "/project", {
            method: "POST",
            headers: authHeader(uid = uid),
            body: JSON.stringify(project),
            redirect: "follow"
        }).then(response => {
            let resp = response.json() as Object
            let pInfo = resp as ProjectInfo
            res(pInfo)
        })
    })
}


export function getProjectDetail_db(uid: string, projectId: String): Promise<ProjectInfo> {
    return new Promise((res, _rej) => {
        fetch(baseURL + "/project/" + projectId, {
            method: "GET",
            headers: authHeader(uid = uid),
            redirect: "follow"
        }).then(response => {
            let resp = response.json() as Object
            let pInfo = resp as ProjectInfo
            res(pInfo)
        })
    })
}


export function putProjectDetail_db(uid: string, project: ProjectInfo): Promise<ProjectInfo> {
    return new Promise((res, _rej) => {
        fetch(baseURL + "/project/" + project.projectId, {
            method: "PUT",
            headers: authHeader(uid = uid),
            body: JSON.stringify(project),
            redirect: "follow"
        }).then(response => {
            let resp = response.json() as Object
            let pInfo = resp as ProjectInfo
            res(pInfo)
        })
    })
}


export function processProject_db(uid: string, project: ProjectInfo): Promise<Boolean> {
    return new Promise((res, _rej) => {
        fetch(baseURL + "/process/" + project.projectId, {
            method: "POST",
            headers: authHeader(uid = uid),
            body: JSON.stringify(project),
            redirect: "follow"
        }).then(response => {
            res(response.status === 200)
        })
    })
}


export function uploadMedia_db(uid: string, projectId: String, file: File): Promise<Boolean> {
    var formdata = new FormData();
    // formdata.append("file", fileInput.files[0], "input.mp4");
    formdata.append("file", file, file.name);

    return new Promise((res, _rej) => {
        fetch(baseURL + "/upload/" + projectId, {
            method: "POST",
            //Default authHeader() was causing a problem because of Content-Type parameter. Media file treated as a json object.
            headers: {"user-id": uid},
            body: formdata,
            redirect: "follow"
        }).then(response => {
            res(response.status === 200)
        })
    })
}


// TODO: Call after having secret url, this should download directly. Or "Use Effect" might be required.
export function downloadMedia_db(downloadPathWithSecret: String) : void {
    let url = baseURL + downloadPathWithSecret
    location.href = url
}

