
export type ProjectSummary = {
    projectId: String;
    projectName: String;
    language?: String;
}

export type ProjectInfo = {
    projectId: String;
    projectName: String;
    language?: "en" | "tr";
    authorizedUIDs: String[];
    duration?: number;
    descriptions: Description[];
    processStatus?: ProcessStatus
}


export type Description = {
    description: String;
    startTime: number;
    dubType: "override" | "stopMotion";
    ttsFile?: String;
}

export type ProcessStatus = {
    inputFileExists: Boolean;
    processedFileExists: Boolean;
    downloadLink?: String;
    secret?: String;
}


export const DubType = {
    stopMotion: "Stop Motion: Stop the Movie until Description Ends",
    override: "Override: Add Voice while Movie is continuing"
}

export type DubTypeKeys = keyof typeof DubType;
