import { ProjectSummary } from "./ProjectTypes";

export type UserInfo = {
    userId: String;
    email: String;
    projects: ProjectSummary[];
    remainingMinutes: number;
}
