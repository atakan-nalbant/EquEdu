let constants = {
    path: {
        login: "login",
        contentStudioProjects: "contentstudio",
        training: "training",
        apiBaseUrl: "https://api.nalbant.me",
    },
    localization : {
        appName: "EquEdu Content Studio",
        leftSideTitle : "Video Overview",
        audioDescriptionsTitle : "Audio Description List",
        enterDesriptionHint : "To add Audio Descriptions, please use Add Description button at the left side.",
        estimatedDuration : "Estimated Duration",
        addDescription : "+ Add Description Here",
        updateDescription : "< Update Description >",
        seconds: "seconds",
        edit: "Edit",
        delete: "Delete",
        uploadProjectButtonName : "Upload and Prepare Movie",
        hintAddDescriptionToPrepare : "Add at least one Description to Prepare Movie"
    },
    wordsPerMinute : 150,
}

export default constants;